export { default as hashPassword } from './hash-password';
