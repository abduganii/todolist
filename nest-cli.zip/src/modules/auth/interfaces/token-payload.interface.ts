interface ITokenPayload {
  userId: string;
}

export default ITokenPayload;
