export { default as ITokenPayload } from './token-payload.interface';
export { default as ILogin } from './login.interface';
